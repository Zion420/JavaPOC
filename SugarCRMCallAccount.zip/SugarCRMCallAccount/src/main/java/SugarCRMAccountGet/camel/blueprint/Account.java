package SugarCRMAccountGet.camel.blueprint;

public class Account {

		private String id;
		private String name;
		private String date_entered;	
		private String date_modified;
		private String modified_user_id;
		private String _acl;
		private String _module;
		
		
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getDate_entered() {
			return date_entered;
		}
		public void setDate_entered(String date_entered) {
			this.date_entered = date_entered;
		}
		public String getDate_modified() {
			return date_modified;
		}
		public void setDate_modified(String date_modified) {
			this.date_modified = date_modified;
		}
		public String getModified_user_id() {
			return modified_user_id;
		}
		public void setModified_user_id(String modified_user_id) {
			this.modified_user_id = modified_user_id;
		}


		public String get_acl() {
			return _acl;
		}
		public void set_acl(String _acl) {
			this._acl = _acl;
		}
		public String get_module() {
			return _module;
		}
		public void set_module(String _module) {
			this._module = _module;
		}
		
		
		
	  
}
