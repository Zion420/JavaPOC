package SugarCRMAccountGet.camel.blueprint;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "AccountCreationRequest")
public class AccountCreationRequest {

	private String name;
	private String account_type;
	private String description;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAccount_type() {
		return account_type;
	}
	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}


		
	  
}
