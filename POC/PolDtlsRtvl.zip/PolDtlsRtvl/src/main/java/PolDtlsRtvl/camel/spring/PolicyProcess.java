package PolDtlsRtvl.camel.spring;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import PolDtlsRtvl.camel.spring.utils.JsonToPojoConverter;

public class PolicyProcess {

	   public Policy status(String policy) throws Exception {
	       // get the id of the input

		   	PolicyProcess polProc = new PolicyProcess();
		   	
		   	Policy pol = new Policy();
		   	
			if (policy.charAt(0) == '1'){		   	
		   	
					Policy poLicy = polProc.acmeDetails(policy);
		   	
					pol = poLicy;
			}

			else if (policy.charAt(0) == '2'){		   	
			   	
				Policy poLicy = polProc.wayneDetails(policy);
	   	
				pol = poLicy;
		    }
			
			else {
				
				pol.setStatus("No Such Policy");;
			}			
			
			return pol;
	   }

	   
	   
	   public Policy acmeDetails(String policy) throws Exception {
	       // get the id of the input
	   	

		       // set reply including the id
		   	PolicyDetailsAccept policyDetails = new PolicyDetailsAccept();
		   	Policy pol = new Policy();
		   	
			   try {
	                
					String check = "http://localhost:8080/AcmeInc/api/policy/" + policy;  
					  
					URL url = new URL(check);
					
					HttpURLConnection conn = (HttpURLConnection) url.openConnection();
					
					conn.setRequestMethod("GET");
					conn.setRequestProperty("Accept", "application/json");
					
					if (conn.getResponseCode() != 200) {
						throw new RuntimeException("Failed : HTTP error code : "
								+ conn.getResponseCode());
					}
	
					
					
					BufferedReader br = new BufferedReader(new InputStreamReader(
						(conn.getInputStream())));
					
					StringBuffer outputAsStringBuffer = new StringBuffer();
					
					String output;
					while ((output = br.readLine()) != null) {
						outputAsStringBuffer.append(output);
					}
					
					output = outputAsStringBuffer.toString();
					policyDetails = JsonToPojoConverter.convertFromJson(output, PolicyDetailsAccept.class);
					
					//System.out.println("account.getAcctLastPremiumPaid(): "+ account.getAcctLastPremiumPaid());
					
					pol.setLastPremiumPaid(policyDetails.getLastPremiumPaid());
					pol.setPolicyNumber(policyDetails.getPolicyNumber());
					pol.setRole(policyDetails.getRole());					
					pol.setStatus(policyDetails.getStatus());
	
					conn.disconnect();
	
				  } catch (MalformedURLException e) {
	
					e.printStackTrace();
	
				  } catch (IOException e) {
	
					e.printStackTrace();
	
				  }
			 
		   	
		   	return pol;
	   }


	   public Policy wayneDetails(String policy) throws Exception {
	       // get the id of the input
	   	
	       // set reply including the id
	   	PolicyDetailsAccept policyDetails = new PolicyDetailsAccept();
	   	Policy pol = new Policy();
	   	
		   try {
                
				String check = "http://localhost:8080/WayneEnt/api/policy/" + policy;  
				  
				URL url = new URL(check);
				
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				
				conn.setRequestMethod("GET");
				conn.setRequestProperty("Accept", "application/json");
				
				if (conn.getResponseCode() != 200) {
					throw new RuntimeException("Failed : HTTP error code : "
							+ conn.getResponseCode());
				}

				
				BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream())));
				
				StringBuffer outputAsStringBuffer = new StringBuffer();
				
				String output;
				while ((output = br.readLine()) != null) {
					outputAsStringBuffer.append(output);
				}
				
				output = outputAsStringBuffer.toString();
				policyDetails = JsonToPojoConverter.convertFromJson(output, PolicyDetailsAccept.class);
				
				//System.out.println("account.getAcctLastPremiumPaid(): "+ account.getAcctLastPremiumPaid());
				
				pol.setLastPremiumPaid(policyDetails.getLastPremiumPaid());
				pol.setPolicyNumber(policyDetails.getPolicyNumber());
				pol.setRole(policyDetails.getRole());					
				pol.setStatus(policyDetails.getStatus());

				conn.disconnect();

			  } catch (MalformedURLException e) {

				e.printStackTrace();

			  } catch (IOException e) {

				e.printStackTrace();

			  }
		 
	   	
	   	return pol;
	   	
	 }

	   
}
