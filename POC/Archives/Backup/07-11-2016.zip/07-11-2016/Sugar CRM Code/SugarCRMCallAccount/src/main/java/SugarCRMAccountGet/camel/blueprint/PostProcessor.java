package SugarCRMAccountGet.camel.blueprint;

import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.cxf.message.MessageContentsList;

public class PostProcessor implements Processor {
	
	public void process(Exchange exchange) throws Exception {
        exchange.setPattern(ExchangePattern.InOut);
        Message inMessage = exchange.getIn();
        // set the operation name
        //inMessage.setHeader(CxfConstants.OPERATION_NAME, "getPoicy");
        // using the proxy client API
        //inMessage.setHeader(CxfConstants.CAMEL_CXF_RS_USING_HTTP_API, Boolean.FALSE);
         

        //creating the request
        IdToken iToken = inMessage.getBody(IdToken.class);

        inMessage.setHeader("OAuth-Token", iToken.getOauthToken());
        exchange.setProperty("OAuth-Token",iToken.getOauthToken()) ;
        
       // AccountCreationRequest accountCreationRequest = new 
        
        
    
        MessageContentsList req = new MessageContentsList();
        //req.add(AccountCreationRequest.class);
        inMessage.setBody(exchange.getUnitOfWork().getOriginalInMessage().getBody()); 

    }


}
