package SugarCRMAccountGet.camel.blueprint;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.json.JSONObject;

import SugarCRMAccountGet.camel.blueprint.utils.JsonToPojoConverter;

public class TokenRetrieve {

	public IdToken getToken(String id) throws Exception {
		
		IdToken IT = new IdToken();
		
		Authentication auth = new Authentication();
		
		String url = "https://zesbne8983.trial.sugarcrm.eu/rest/v10/oauth2/token";

		JSONObject requestJson = new JSONObject();
		
		requestJson = generateJSON();

		//System.out.println("generated String" + requestJson.toString());

		URL myurl = new URL(url);
		HttpURLConnection con = (HttpURLConnection) myurl.openConnection();
		con.setDoOutput(true);
		con.setDoInput(true);

		con.setRequestProperty("Content-Type", "application/json");
		con.setRequestProperty("Accept", "application/json");
		con.setRequestProperty("Method", "POST");
		OutputStream os = con.getOutputStream();
		os.write(requestJson.toString().getBytes("UTF-8"));
		os.close();

		//System.out.println("url hit" + url);//
		
		StringBuilder sb = new StringBuilder();
		Integer HttpResult = con.getResponseCode();
		//System.out.println("Response code" + HttpResult.toString());
		
		
/*		if ((HttpResult == HttpURLConnection.HTTP_OK) || (HttpResult == 204)) {
			BufferedReader br = new BufferedReader(new InputStreamReader(
					con.getInputStream(), "utf-8"));

			String line = null;
			while ((line = br.readLine()) != null) {
				sb.append(line + "\n");
			}
			br.close();
			System.out.println("" + sb.toString());

		} else {
			System.out.println(con.getResponseCode());
			System.out.println(con.getResponseMessage());
		}
*/		
		
		BufferedReader br = new BufferedReader(new InputStreamReader(
				con.getInputStream()));
		
		StringBuffer outputAsStringBuffer = new StringBuffer();
		
		String output;
		while ((output = br.readLine()) != null) {
			outputAsStringBuffer.append(output);
		}
		br.close();
		
		output = outputAsStringBuffer.toString();
		
		auth = JsonToPojoConverter.convertFromJson(output, Authentication.class);
		
		
		//System.out.println("Fields came from SugarCRM" +output);

		
		IT.setId(id);
		IT.setOauthToken(auth.getAccess_token());
		
		
		return IT;
	}

	public IdToken haveToken() throws Exception {
		
		IdToken IT = new IdToken();
		
		Authentication auth = new Authentication();
		
		String url = "https://zesbne8983.trial.sugarcrm.eu/rest/v10/oauth2/token";

		JSONObject requestJson = new JSONObject();
		
		requestJson = generateJSON();

		//System.out.println("generated String" + requestJson.toString());

		URL myurl = new URL(url);
		HttpURLConnection con = (HttpURLConnection) myurl.openConnection();
		con.setDoOutput(true);
		con.setDoInput(true);

		con.setRequestProperty("Content-Type", "application/json");
		con.setRequestProperty("Accept", "application/json");
		con.setRequestProperty("Method", "POST");
		OutputStream os = con.getOutputStream();
		os.write(requestJson.toString().getBytes("UTF-8"));
		os.close();

		//System.out.println("url hit" + url);//
		
		StringBuilder sb = new StringBuilder();
		Integer HttpResult = con.getResponseCode();
		//System.out.println("Response code" + HttpResult.toString());
		
		BufferedReader br = new BufferedReader(new InputStreamReader(
				con.getInputStream()));
		
		StringBuffer outputAsStringBuffer = new StringBuffer();
		
		String output;
		while ((output = br.readLine()) != null) {
			outputAsStringBuffer.append(output);
		}
		br.close();
		
		output = outputAsStringBuffer.toString();
		
		auth = JsonToPojoConverter.convertFromJson(output, Authentication.class);
		
		
		//System.out.println("Fields came from SugarCRM" +output);

		
		IT.setId("");
		IT.setOauthToken(auth.getAccess_token());
		
		
		return IT;
	}

	
	public static JSONObject generateJSON()
			throws MalformedURLException

	{

		JSONObject reqparam = new JSONObject();
		reqparam.accumulate("grant_type", "password");
		reqparam.accumulate("client_id", "sugar");
		reqparam.accumulate("client_secret", "");
		reqparam.accumulate("username", "jim");
		reqparam.accumulate("password", "jim");
		reqparam.accumulate("platform", "base");		
		return reqparam;

	}

	
}
