package org.blogdemo.claimdemo;

import java.util.ArrayList;
import java.util.List;

public class PolicyProcessor {
	public ClaimOutput process(ClaimInput input) throws Exception {
        // get the id of the input
    	//ClaimInput input = exchange.getIn().getBody(ClaimInput.class);

    	System.out.println(input);
    	
    	// set reply including the id
        ClaimOutput output = new ClaimOutput();
        output.setClaimNo("A00099484");
        output.setCustomerName(input.getCustomerName());
        output.setStatus("DONE");
        //exchange.getOut().setBody(output);
        return output;
    }
	
	 public ClaimStatus cancel(String claimNo) throws Exception {
	      
			ClaimStatus status = new ClaimStatus();
		   	status.setClaimNo(claimNo);
		   	status.setStatus("OK");
		   	
		   	return status;
	   }
	 
	 
	 
	   
	   public ClaimStatus status1(String id) throws Exception {
	       // get the id of the input
	   	//ClaimInput input = exchange.getIn().getBody(ClaimInput.class);

	   	System.out.println(id);
	   	System.out.println("ClaimInput :["+ClaimInput.class.getPackage().getName()+"]");
	   	
	       // set reply including the id
	   	ClaimStatus status = new ClaimStatus();
	   	status.setCustomerID(id);
	   	status.setPolno("11111");
	   	status.setClaimNo("34567789");
	   	status.setStatus("OK from 1");
	   
	   	return status;
	   }
	   
	   public ClaimStatus status2(String id) throws Exception {
	       // get the id of the input
	   	//ClaimInput input = exchange.getIn().getBody(ClaimInput.class);

	   	System.out.println(id);
	   	System.out.println("ClaimInput :["+ClaimInput.class.getPackage().getName()+"]");
	   	
	       // set reply including the id
	   	ClaimStatus status = new ClaimStatus();
	   	status.setCustomerID("22222");
	   	status.setPolno("22222");
	   	status.setClaimNo("34567789");
	   	status.setStatus("OK from 2");
	   
	   	return status;
	   }
	   
	   public List<String> prepareList(String polno){
		   final List<String> params = new ArrayList<String>();
		   params.add(polno);
		   
		   return params;
	   }
}
