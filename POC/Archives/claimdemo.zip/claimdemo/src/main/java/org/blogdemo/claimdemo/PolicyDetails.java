package org.blogdemo.claimdemo;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The Customer class is just a plain old java object, with a few properties and getters and setters.
 * <p/>
 * By adding the @XmlRootElement annotation, we make it possible for JAXB to unmarshal this object into a XML document and
 * to marshal it back from the same XML document.
 * <p/>
 * The XML representation of a Customer will look like this:
 * <Customer>
 * <id>123</id>
 * <name>National Aquarium</name>
 * </Customer>
 */
@XmlRootElement(name = "PolicyDetails")
public class PolicyDetails {
	
	String lastPremiumPaid = "";
	String policyNumber = "";
	String role = "";
	String status = "";

	public String getLastPremiumPaid() {
		return lastPremiumPaid;
	}
	public void setLastPremiumPaid(String lastPremiumPaid) {
		this.lastPremiumPaid = lastPremiumPaid;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	
	
	
	
	
}
