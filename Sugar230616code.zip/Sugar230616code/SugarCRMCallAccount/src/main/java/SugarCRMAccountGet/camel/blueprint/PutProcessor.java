package SugarCRMAccountGet.camel.blueprint;

import java.net.MalformedURLException;

import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.cxf.message.MessageContentsList;
import org.json.JSONObject;

public class PutProcessor implements Processor {
	
	public void process(Exchange exchange) throws Exception {
        exchange.setPattern(ExchangePattern.InOut);
        Message inMessage = exchange.getIn();
        // set the operation name
        //inMessage.setHeader(CxfConstants.OPERATION_NAME, "getPoicy");
        // using the proxy client API
        inMessage.setHeader(CxfConstants.CAMEL_CXF_RS_USING_HTTP_API, Boolean.FALSE);

		/*String accId = inMessage.getBody(String.class);
		exchange.setProperty("RequestId", accId);*/

        //creating the request
        Account acct = inMessage.getBody(Account.class);
        
        exchange.setProperty("ReqId",acct.getId()) ;
        
		JSONObject requestJson = new JSONObject(); 
		
		requestJson = generateJSON(acct);
		
        //inMessage.setHeader("OAuth-Token", iToken.getOauthToken());
        //exchange.setProperty("OAuth-Token",acct.getOauthToken()) ;
        MessageContentsList req = new MessageContentsList();
        req.add(requestJson.toString());
        inMessage.setBody(req);

    }
	
	public static JSONObject generateJSON(Account act)
			throws MalformedURLException

	{

		JSONObject reqparam = new JSONObject();
		reqparam.accumulate("id", act.getId());
		reqparam.accumulate("name", act.getName());
		reqparam.accumulate("date_entered", act.getDate_entered());
		reqparam.accumulate("date_modified", act.getDate_modified());
		reqparam.accumulate("modified_user_id", act.getModified_user_id());
		reqparam.accumulate("description", act.getDescription());
		reqparam.accumulate("title", act.getTitle());	
/*		reqparam.accumulate("_acl", act.get_acl());	
		reqparam.accumulate("_module", act.get_module());			
*/		return reqparam;

	}



}
