package SugarCRMAccountGet.camel.blueprint;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.json.JSONObject;

import SugarCRMAccountGet.camel.blueprint.utils.JsonToPojoConverter;

public class CallServer {
	
	public void sendDetails(String S) throws Exception {
		
		
		Account act = new Account();
		
		act = JsonToPojoConverter.convertFromJson(S, Account.class);
		
		String url_back = act.getId();
		
		String url = "https://lgwtrc6342.trial.sugarcrm.eu/rest/v10/Accounts/";		
		
		JSONObject requestJson = new JSONObject();
		
		requestJson = generateJSON(act);

		System.out.println("generated String for PUT" + requestJson.toString());

		URL myurl = new URL(url);
		HttpURLConnection con = (HttpURLConnection) myurl.openConnection();
		con.setDoOutput(true);
		con.setDoInput(true);

		con.setRequestProperty("Content-Type", "application/json");
		//con.setRequestProperty("OAuth-Token", "c52f2b4d-51de-8c04-761f-576b74a7acc1");
		con.setRequestProperty("Accept", "application/json");
		con.setRequestProperty("Method", "POST");
		OutputStream os = con.getOutputStream();
		os.write(requestJson.toString().getBytes("UTF-8"));
		os.close();

		//System.out.println("url hit" + url);//
		
		StringBuilder sb = new StringBuilder();
		Integer HttpResult = con.getResponseCode();
		System.out.println("Response code" + HttpResult.toString());
		
		
		if ((HttpResult == HttpURLConnection.HTTP_OK) || (HttpResult == 204)) {
			BufferedReader br = new BufferedReader(new InputStreamReader(
					con.getInputStream(), "utf-8"));

			String line = null;
			while ((line = br.readLine()) != null) {
				sb.append(line + "\n");
			}
			br.close();
			System.out.println("" + sb.toString());

		} else {
			System.out.println(con.getResponseCode());
			System.out.println(con.getResponseMessage());
		}
		
		
		BufferedReader br = new BufferedReader(new InputStreamReader(
				con.getInputStream()));
		
		StringBuffer outputAsStringBuffer = new StringBuffer();
		
		String output;
		while ((output = br.readLine()) != null) {
			outputAsStringBuffer.append(output);
		}
		br.close();
		
		output = outputAsStringBuffer.toString();
		
		System.out.println("Fields came from SugarCRM" +output);

		
		}

	public static JSONObject generateJSON(Account act)
			throws MalformedURLException

	{

		JSONObject reqparam = new JSONObject();
		reqparam.accumulate("id", act.getId());
		reqparam.accumulate("name", act.getName());
		reqparam.accumulate("date_entered", act.getDate_entered());
		reqparam.accumulate("date_modified", act.getDate_modified());
		reqparam.accumulate("modified_user_id", act.getModified_user_id());
		reqparam.accumulate("description", act.getDescription());	
/*		reqparam.accumulate("_acl", act.get_acl());	
		reqparam.accumulate("_module", act.get_module());			
*/		return reqparam;

	}

	

}
