package SugarCRMAccountGet.camel.blueprint;

public class IdToken {

	private String id;
	private String oauthToken;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getOauthToken() {
		return oauthToken;
	}
	public void setOauthToken(String oauthToken) {
		this.oauthToken = oauthToken;
	}

	
	
}
