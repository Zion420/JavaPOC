package SugarCRMAccountGet.camel.blueprint;

public interface PostService {

}
